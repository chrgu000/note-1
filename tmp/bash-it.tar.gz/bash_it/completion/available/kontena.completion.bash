which kontena > /dev/null && . "$( kontena whoami --bash-completion-path )"
